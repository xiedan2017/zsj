<?php
return array(
	//'配置项'=>'配置值'
	'TMPL_PARSE_STRING'=>array(
	  '__PUBLIC__'=>__ROOT__.'/APP/'. MODULE_NAME . '/View/Public',
	),
);
?>