<?php
return array(
	//'配置项'=>'配置值'
	'DEFAULT_MODULE'  => 'Index', //默认模块
	// 数据库配置
	'DB_TYPE'   => 'MySQL', // 数据库类型
    'DB_HOST'   => '124.172.156.220', // 服务器地址
    'DB_NAME'   => 'biruan', // 数据库名
    'DB_USER'   => 'biruan_f', // 用户名
    'DB_PWD'    => 'han8023zhai', // 密码
    'DB_PORT'   => 3306, // 端口
    'DB_PREFIX' => 'klwl_', // 数据库表前缀
    'url'=>'http://bi-rept.com',
    'URL_MODEL'=>2
);